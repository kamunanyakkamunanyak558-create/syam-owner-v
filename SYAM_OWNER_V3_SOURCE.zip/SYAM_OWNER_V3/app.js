const $=id=>document.getElementById(id);
const STORE='syam_owner_v3_notes';
let notes=loadNotes(),editingId=null;
function loadNotes(){try{return JSON.parse(localStorage.getItem(STORE)||'[]')}catch{return []}}
function persist(){localStorage.setItem(STORE,JSON.stringify(notes));renderNotes()}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderNotes(){$('noteCount').textContent=notes.length;const list=$('notesList');if(!notes.length){list.innerHTML='<div class="empty">Belum ada catatan.<br>Tekan “Baru” untuk membuat catatan pertama.</div>';return}list.innerHTML=notes.slice().sort((a,b)=>b.updated-a.updated).map(n=>`<article class="note"><h3>${escapeHTML(n.title||'Tanpa judul')}</h3><p>${escapeHTML(n.body||'')}</p><div class="note-actions"><button class="secondary" data-edit="${n.id}">Edit</button><button class="secondary" data-delete="${n.id}">Hapus</button></div></article>`).join('')}
function showTab(name){document.querySelectorAll('.view').forEach(v=>v.classList.toggle('hidden',v.id!==name));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name))}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
$('viewNotes').onclick=()=>showTab('notes');
function openNote(id=null){editingId=id;const n=notes.find(x=>x.id===id);$('dialogTitle').textContent=n?'Edit catatan':'Catatan baru';$('noteTitle').value=n?.title||'';$('noteBody').value=n?.body||'';$('noteDialog').showModal();setTimeout(()=>$('noteTitle').focus(),50)}
['newNote','newNote2','quickNote'].forEach(id=>$(id).onclick=()=>openNote());
$('noteForm').addEventListener('submit',e=>{if(e.submitter?.value!=='save')return;e.preventDefault();const title=$('noteTitle').value.trim(),body=$('noteBody').value.trim();if(!title&&!body){$('noteTitle').focus();return}if(editingId){const n=notes.find(x=>x.id===editingId);if(n)Object.assign(n,{title,body,updated:Date.now()})}else notes.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),title,body,created:Date.now(),updated:Date.now()});persist();$('noteDialog').close();showTab('notes')});
$('notesList').addEventListener('click',e=>{const edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');if(edit)openNote(edit.dataset.edit);if(del&&confirm('Hapus catatan ini?')){notes=notes.filter(n=>n.id!==del.dataset.delete);persist()}});
$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify({app:'SYAM OWNER V3',exportedAt:new Date().toISOString(),notes},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='syam-owner-v3-data.json';a.click();URL.revokeObjectURL(a.href)};
$('clearData').onclick=()=>{if(confirm('Yakin menghapus semua catatan? Tindakan ini tidak dapat dibatalkan.')){notes=[];persist()}};
$('animations').onchange=e=>document.body.classList.toggle('no-animations',!e.target.checked);
$('contrast').onchange=e=>document.body.classList.toggle('high-contrast',e.target.checked);
$('soundBtn').onclick=()=>{alert('Kontrol musik siap. Untuk mengaktifkan backsound, tambahkan file audio milikmu sebagai music.mp3 dan hubungkan ke elemen audio. Versi ini tidak menyertakan musik berhak cipta.');};
renderNotes();