# SYAM OWNER V3 — Android-ready web app

Aplikasi panel bergaya neon ungu untuk pengujian, dengan catatan lokal, ekspor JSON, pengaturan kontras dan efek animasi.

## Isi
- `index.html`, `style.css`, `app.js`: source aplikasi.
- `.github/workflows/android-build.yml`: build APK debug menggunakan Capacitor + Android SDK di GitHub Actions.

## Build dari HP Android
1. Buat repository GitHub baru.
2. Upload semua file dan folder dari ZIP ini ke root repository (termasuk folder `.github`).
3. Buka tab **Actions**, pilih **Build SYAM Owner V3 APK**, tekan **Run workflow**.
4. Setelah job selesai dengan status hijau, buka run tersebut, bagian **Artifacts**, unduh `syam-owner-v3-debug-apk`.
5. Ekstrak ZIP artifact dan pasang `app-debug.apk` di perangkat uji. Android mungkin meminta izin memasang aplikasi dari sumber ini.

## Catatan
Ini adalah aplikasi demo lokal, bukan panel serangan atau alat untuk mengganggu WhatsApp. Tidak ada akun Owner/Reseller sungguhan, backend, sinkronisasi cloud, atau autentikasi server. Jangan masukkan kata sandi atau data rahasia. Build membutuhkan GitHub Actions aktif dan workflow berhasil.
